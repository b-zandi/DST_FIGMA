--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: faqs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    category text NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.faqs OWNER TO neondb_owner;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO neondb_owner;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: investments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.investments (
    id integer NOT NULL,
    title text NOT NULL,
    location text NOT NULL,
    property_type text NOT NULL,
    asset_class text NOT NULL,
    min_investment integer NOT NULL,
    projected_yield text NOT NULL,
    offering_size text NOT NULL,
    hold_period text NOT NULL,
    image_url text NOT NULL,
    description text NOT NULL,
    status text NOT NULL,
    sponsor text NOT NULL,
    property_address text NOT NULL,
    year_built text NOT NULL,
    square_feet text NOT NULL,
    occupancy text NOT NULL,
    offering_date text NOT NULL,
    closing_date text NOT NULL,
    distribution_frequency text NOT NULL,
    debt_financing text NOT NULL,
    tax_advantages text NOT NULL,
    detailed_description text NOT NULL
);


ALTER TABLE public.investments OWNER TO neondb_owner;

--
-- Name: investments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.investments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investments_id_seq OWNER TO neondb_owner;

--
-- Name: investments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.investments_id_seq OWNED BY public.investments.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO neondb_owner;

--
-- Name: user_investments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_investments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    investment_id integer NOT NULL,
    investment_amount numeric NOT NULL,
    investment_date timestamp without time zone DEFAULT now(),
    ownership_percentage numeric NOT NULL,
    distributions_paid numeric DEFAULT '0'::numeric,
    last_distribution_date timestamp without time zone,
    investment_status text NOT NULL
);


ALTER TABLE public.user_investments OWNER TO neondb_owner;

--
-- Name: user_investments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_investments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_investments_id_seq OWNER TO neondb_owner;

--
-- Name: user_investments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_investments_id_seq OWNED BY public.user_investments.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    password text NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    phone text,
    accredited_status boolean DEFAULT false,
    accreditation_score integer DEFAULT 0,
    accreditation_segment text DEFAULT 'notReady'::text,
    questionnaire_data text,
    is_profile_complete boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    accredited text,
    sale_status text,
    equity_bracket text,
    horizon text,
    return_need text,
    passive_importance integer,
    location text,
    property_type text,
    mortgage_bracket text,
    prior_1031 text,
    qi_ready text,
    risk_tolerance integer,
    advisor text,
    notes text,
    truthful_acknowledgement boolean,
    updated_at timestamp without time zone DEFAULT now(),
    reset_token text,
    reset_token_expiry timestamp without time zone
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: investments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.investments ALTER COLUMN id SET DEFAULT nextval('public.investments_id_seq'::regclass);


--
-- Name: user_investments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_investments ALTER COLUMN id SET DEFAULT nextval('public.user_investments_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.faqs (id, question, answer, category, "order") FROM stdin;
\.


--
-- Data for Name: investments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.investments (id, title, location, property_type, asset_class, min_investment, projected_yield, offering_size, hold_period, image_url, description, status, sponsor, property_address, year_built, square_feet, occupancy, offering_date, closing_date, distribution_frequency, debt_financing, tax_advantages, detailed_description) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.session (sid, sess, expire) FROM stdin;
JT9Uz6XIb7BkrX58f3ltLt34YgpMqB7B	{"cookie":{"originalMaxAge":86400000,"expires":"2025-05-30T18:46:42.455Z","secure":false,"httpOnly":true,"path":"/"}}	2025-05-31 14:01:28
\.


--
-- Data for Name: user_investments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_investments (id, user_id, investment_id, investment_amount, investment_date, ownership_percentage, distributions_paid, last_distribution_date, investment_status) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, password, email, first_name, last_name, phone, accredited_status, accreditation_score, accreditation_segment, questionnaire_data, is_profile_complete, created_at, accredited, sale_status, equity_bracket, horizon, return_need, passive_importance, location, property_type, mortgage_bracket, prior_1031, qi_ready, risk_tolerance, advisor, notes, truthful_acknowledgement, updated_at, reset_token, reset_token_expiry) FROM stdin;
1	2eb97a10444d91098105dbaace46bda28379945a93379e89a466036ebedc9b683d1c0f49bf4a8da9c565288a38356d2c8da59a0a0c3ffcdc6d45a68075101db2.84a272b8c6ec959d46ca2ae3a8518c43	test4@gmail.com	\N	\N	\N	t	102	high	{"accredited":"yes","saleStatus":"active","equityBracket":"500-999","horizon":"5-10","returnNeed":"5-6","passiveImportance":4,"location":"19146","propertyType":"multifamily","mortgageBracket":"25to50","prior1031":"yes","qiReady":"no","riskTolerance":2,"advisor":"yes","notes":""}	f	2025-05-05 20:23:43.712242	yes	active	500-999	5-10	5-6	4	19146	multifamily	25to50	yes	no	2	yes		f	2025-05-28 16:59:54.425266	\N	\N
7	436dab886da4d1ca2050b2e2eebb943746117c2a5824e7dcf5128277ffc2b3dd14bacd5c643df5ab3a9134962d02cd47ce60ca20fd1c9420dc0f6fc54a8712a6.7c2a1f837dd11592f7a0682f599787b5	test9@gmail.com	Jen 	Zandi 	\N	t	83	high	{"accredited":"yes","saleStatus":"lt6","equityBracket":"500-999","horizon":"5-10","returnNeed":"7-8","passiveImportance":3,"location":"19146","propertyType":"industrial","mortgageBracket":"lt25","prior1031":"yes","qiReady":"no","riskTolerance":5,"advisor":"no","notes":"","truthfulAcknowledgement":true}	f	2025-05-08 02:59:22.591307	yes	lt6	500-999	5-10	7-8	3	19146	industrial	lt25	yes	no	5	no		t	2025-05-28 16:59:54.425266	\N	\N
8	33c9229a2b50b2f2cbaff8dcbd370688578ac584fc379970c2f1efdcf0d24362ed9bc06523f4684abaaf4dcd392b712eaf483a3782e063e2fd93486305cb588f.24238dfbf094efe9a43286b7d96b0785	test10@gmail.com	Bill 	Zandi 	6105518303	f	62	medium	{"accredited":"notSure","saleStatus":"lt12","equityBracket":"250-499","horizon":"5-10","returnNeed":"5-6","passiveImportance":2,"location":"19146","propertyType":"land","mortgageBracket":"lt25","prior1031":"no","qiReady":"no","riskTolerance":3,"advisor":"no","notes":"","truthfulAcknowledgement":true}	t	2025-05-08 12:37:05.309074	notSure	lt12	250-499	5-10	5-6	2	19146	land	lt25	no	no	3	no		t	2025-05-28 16:59:54.425266	\N	\N
9	0a5da68e13f4537f8476685c0b8a490442ab8839b489e7e9142260b205a96dd29c7e62666626cf146b43d17216e94e1c55327f94916ef5da83442aa8bdc39781.bcacc63a33c38dd0735a3e736015842b	mbastockman@gmail.com	Fred	Hubler	6105646517	t	75	medium	{"accredited":"yes","saleStatus":"ownNoSale","equityBracket":"1mPlus","horizon":"5-10","returnNeed":"ge9","passiveImportance":5,"location":"19460","propertyType":"office","mortgageBracket":"lt25","prior1031":"yes","qiReady":"no","riskTolerance":4,"advisor":"yes","notes":"Fred is great and not very tall lol. ","truthfulAcknowledgement":true}	t	2025-05-08 14:42:15.656392	yes	ownNoSale	1mPlus	5-10	ge9	5	19460	office	lt25	yes	no	4	yes	Fred is great and not very tall lol. 	t	2025-05-28 16:59:54.425266	\N	\N
10	af8083a8e314f6c186169bfb57178f67b9ea7efae468bc8128fe5bdeff592e915f161e811c11d88ffa6d0f0923608c1223140c1f0b4e0afbd2d862495f2eeaf3.48e657fb542eb3a09457ce1ab5d70ddf	babson03@gmail.com	Andrew	Babson	2022512133	t	90	high	{"accredited":"yes","saleStatus":"lt6","equityBracket":"500-999","horizon":"10+","returnNeed":"5-6","passiveImportance":4,"location":"19122","propertyType":"industrial","mortgageBracket":"lt25","prior1031":"no","qiReady":"no","riskTolerance":5,"advisor":"yes","notes":"","truthfulAcknowledgement":true}	t	2025-05-08 15:03:26.593051	yes	lt6	500-999	10+	5-6	4	19122	industrial	lt25	no	no	5	yes		t	2025-05-28 16:59:54.425266	\N	\N
11	3edfcc467c8222e1a387edc4c589e457d72d46231e6e072aed4b7577f0c7d21d5524532178480c89e1e1e550f7ec9b9472bc7fa6bc42d81b1c21d76f5ba36595.dcde36f24f57112f92b1cad35ad32e8c	mohit@gmail.com	Mohit	M	\N	t	78	medium	{"accredited":"yes","saleStatus":"lt6","equityBracket":"500-999","horizon":"3-5","returnNeed":"5-6","passiveImportance":3,"location":"19146","propertyType":"retail","mortgageBracket":"lt25","prior1031":"no","qiReady":"no","riskTolerance":3,"advisor":"no","notes":"","truthfulAcknowledgement":true}	f	2025-05-13 16:42:48.021906	yes	lt6	500-999	3-5	5-6	3	19146	retail	lt25	no	no	3	no		t	2025-05-28 16:59:54.425266	\N	\N
13	a1061a3ca9b279dfa586cc3a46e369d01323049a9157f7d395d2bfcaf535fd101635d92f24f4f539b74378c57b8c608bc792a2dd0718f1512e6417895186de3a.ae16397ec5627b33a44c5abb61869306	testuser@example.com	Test	User	\N	f	0	notReady	\N	f	2025-05-28 17:03:39.991334	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-05-28 17:03:39.991334	\N	\N
14	5784d5a40ffe4a7e67d5176bfccb113a1a1faf950d4125f7a06fa9a4a0903234ed16c61c715a85b8aa189a777f1c773f4fe89026dad07f425c08615ffe0314be.4fcd930bd306d3f12b185ad52f3553e2	manna2@purdue.edu	Mohit	Manna	6107101671	t	88	high	{"accredited":"yes","saleStatus":"active","equityBracket":"1mPlus","horizon":"<3","returnNeed":"7-8","passiveImportance":4,"location":"19087","propertyType":"office","mortgageBracket":"lt25","prior1031":"yes","qiReady":"yes","riskTolerance":5,"advisor":"yes","notes":"DST is very cool!","truthfulAcknowledgement":true}	t	2025-05-29 18:30:48.750787	yes	active	1mPlus	<3	7-8	4	19087	office	lt25	yes	yes	5	yes	DST is very cool!	t	2025-05-29 18:30:48.750787	471a21cb8c53cc1e20ee3f0f4881084ff1d2b9542d6e6de620a8a97dd060c131	2025-05-29 19:41:49.708
12	b2c9624263a64329acab7930f5a813291b3e37f6469c363d45ef82bc95b4da1f09fd77908711866b73386b3e066472cb9f5530b5b7ef3cb089fd9d7ced7caa23.9d1879d113369cb829b1ed9b76dc00c0	mannamohit542@gmail.com	Mohit	Manna	\N	f	39	notReady	{"accredited":"no","saleStatus":"active","equityBracket":"250-499","horizon":"3-5","returnNeed":"7-8","passiveImportance":3,"location":"19087","propertyType":"multifamily","mortgageBracket":"lt25","prior1031":"no","qiReady":"no","riskTolerance":3,"advisor":"yes","notes":"","truthfulAcknowledgement":true}	f	2025-05-23 13:42:11.695161	no	active	250-499	3-5	7-8	3	19087	multifamily	lt25	no	no	3	yes		t	2025-05-28 16:59:54.425266	9841b87b6cc3c30034d23f9c1459aa03d6f728e1b633f24c71f97c02f29ce498	2025-05-29 19:40:33.15
15	265b94136208c764187bbee48ab6fe8b8c4cd143ed41127c6536fd3364a96880edd3f1983329238094f8885de42616957f840c8482058189b7d1462add99efbc.304a3f9e2ba8b4c40769c265ad4bf0c6	myboyzz1234@gmail.com	Mohit	Manna	\N	t	93	high	{"accredited":"yes","saleStatus":"active","equityBracket":"500-999","horizon":"3-5","returnNeed":"7-8","passiveImportance":3,"location":"19087","propertyType":"retail","mortgageBracket":"gt50","prior1031":"yes","qiReady":"yes","riskTolerance":5,"advisor":"yes","notes":"No","truthfulAcknowledgement":true}	f	2025-05-29 18:46:40.184776	yes	active	500-999	3-5	7-8	3	19087	retail	gt50	yes	yes	5	yes	No	t	2025-05-29 18:46:40.184776	e9e2812eeb2e6337a2c2e5bab6c90b552ffb257309285047f63ae44a85e884f3	2025-05-29 19:53:50.451
6	54d1e7a58405f0ab54fcc6db250341c69811021cb4d202ca7b4e9cde9337c2c04b4941a899653f81dc6aa82875accd0d7ffe341948e17b4750ec08ea4a2f7c39.5a86f6d80627c2f723ddc7cbf8bffc1a	bill.zandi@gmail.com	William	Zandi	\N	t	84	high	{"accredited":"yes","saleStatus":"active","equityBracket":"250-499","horizon":"3-5","returnNeed":"5-6","passiveImportance":3,"location":"19146","propertyType":"industrial","mortgageBracket":"25to50","prior1031":"yes","qiReady":"no","riskTolerance":4,"advisor":"no","notes":"","truthfulAcknowledgement":true}	f	2025-05-07 22:15:00.713214	yes	active	250-499	3-5	5-6	3	19146	industrial	25to50	yes	no	4	no		t	2025-05-28 16:59:54.425266	5fb3799e871987bc639017ffcb536bb8f31ca01fa22d3029c00b99c10f7a2680	2025-05-30 14:56:30.177
\.


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.faqs_id_seq', 1, false);


--
-- Name: investments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.investments_id_seq', 1, false);


--
-- Name: user_investments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_investments_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 15, true);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: investments investments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.investments
    ADD CONSTRAINT investments_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: user_investments user_investments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_investments
    ADD CONSTRAINT user_investments_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

